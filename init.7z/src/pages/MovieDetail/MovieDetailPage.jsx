import React from 'react'

export const MovieDetailPage = () => {
  return (
    <div>MovieDetailPage</div>
  )
}
